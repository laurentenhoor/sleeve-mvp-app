(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Logger, TypeScriptCompiler, inputFiles, TypeScript, options;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:typescript-compiler":{"logger.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/logger.js                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const util = Npm.require('util');

class Logger_ {
  constructor() {
    this.llevel = process.env.TYPESCRIPT_LOG;
  }

  newProfiler(name) {
    let profiler = new Profiler(name);
    if (this.isProfile) profiler.start();
    return profiler;
  }

  get isDebug() {
    return this.llevel >= 2;
  }

  get isProfile() {
    return this.llevel >= 3;
  }

  get isAssert() {
    return this.llevel >= 4;
  }

  log(msg, ...args) {
    if (this.llevel >= 1) {
      console.log.apply(null, [msg].concat(args));
    }
  }

  debug(msg, ...args) {
    if (this.isDebug) {
      this.log.apply(this, msg, args);
    }
  }

  assert(msg, ...args) {
    if (this.isAssert) {
      this.log.apply(this, msg, args);
    }
  }

}

;
Logger = new Logger_();

class Profiler {
  constructor(name) {
    this.name = name;
  }

  start() {
    console.log('%s started', this.name);
    console.time(util.format('%s time', this.name));
    this._started = true;
  }

  end() {
    if (this._started) {
      console.timeEnd(util.format('%s time', this.name));
    }
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"file-utils.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/file-utils.js                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  isBare: () => isBare,
  isMainConfig: () => isMainConfig,
  isConfig: () => isConfig,
  isServerConfig: () => isServerConfig,
  isDeclaration: () => isDeclaration,
  isWeb: () => isWeb,
  getExtendedPath: () => getExtendedPath,
  getES6ModuleName: () => getES6ModuleName,
  WarnMixin: () => WarnMixin,
  extendFiles: () => extendFiles
});

const colors = Npm.require('colors');

function isBare(inputFile) {
  const fileOptions = inputFile.getFileOptions();
  return fileOptions && fileOptions.bare;
}

function isMainConfig(inputFile) {
  if (!isWeb(inputFile)) return false;
  const filePath = inputFile.getPathInPackage();
  return (/^tsconfig\.json$/.test(filePath)
  );
}

function isConfig(inputFile) {
  const filePath = inputFile.getPathInPackage();
  return (/tsconfig\.json$/.test(filePath)
  );
}

function isServerConfig(inputFile) {
  if (isWeb(inputFile)) return false;
  const filePath = inputFile.getPathInPackage();
  return (/^server\/tsconfig\.json$/.test(filePath)
  );
}

function isDeclaration(inputFile) {
  return TypeScript.isDeclarationFile(inputFile.getBasename());
}

function isWeb(inputFile) {
  const arch = inputFile.getArch();
  return (/^web/.test(arch)
  );
}

function getExtendedPath(inputFile) {
  let packageName = inputFile.getPackageName();
  packageName = packageName ? packageName.replace(':', '_') + '/' : '';
  const inputFilePath = inputFile.getPathInPackage();
  return packageName + inputFilePath;
}

function getES6ModuleName(inputFile) {
  const extended = getExtendedPath(inputFile);
  return TypeScript.removeTsExt(extended);
}

const WarnMixin = {
  warn(error) {
    console.log(`${error.sourcePath} (${error.line}, ${error.column}): ${error.message}`);
  },

  logError(error) {
    console.log(colors.red(`${error.sourcePath} (${error.line}, ${error.column}): ${error.message}`));
  }

};

function extendFiles(inputFiles, fileMixin) {
  inputFiles.forEach(inputFile => _.defaults(inputFile, fileMixin));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript-compiler.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/typescript-compiler.js                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const module1 = module;
let getExtendedPath, isDeclaration, isConfig, isMainConfig, isServerConfig, isBare, getES6ModuleName, WarnMixin, extendFiles, isWeb;
module1.watch(require("./file-utils"), {
  getExtendedPath(v) {
    getExtendedPath = v;
  },

  isDeclaration(v) {
    isDeclaration = v;
  },

  isConfig(v) {
    isConfig = v;
  },

  isMainConfig(v) {
    isMainConfig = v;
  },

  isServerConfig(v) {
    isServerConfig = v;
  },

  isBare(v) {
    isBare = v;
  },

  getES6ModuleName(v) {
    getES6ModuleName = v;
  },

  WarnMixin(v) {
    WarnMixin = v;
  },

  extendFiles(v) {
    extendFiles = v;
  },

  isWeb(v) {
    isWeb = v;
  }

}, 0);
let getShallowHash;
module1.watch(require("./utils"), {
  getShallowHash(v) {
    getShallowHash = v;
  }

}, 1);

const async = Npm.require('async');

const path = Npm.require('path');

const fs = Npm.require('fs');

const Future = Npm.require('fibers/future');

const {
  TSBuild,
  validateTsConfig,
  getExcludeRegExp
} = Npm.require('meteor-typescript');

const {
  createHash
} = Npm.require('crypto');

// Default exclude paths.
const defExclude = new RegExp(getExcludeRegExp(['node_modules/**'])); // What to exclude when compiling for the server.
// typings/main and typings/browser seem to be not used
// at all but let keep them for just in case.

const exlWebRegExp = new RegExp(getExcludeRegExp(['typings/main/**', 'typings/main.d.ts'])); // What to exclude when compiling for the client.

const exlMainRegExp = new RegExp(getExcludeRegExp(['typings/browser/**', 'typings/browser.d.ts']));
const COMPILER_REGEXP = /(\.d.ts|\.ts|\.tsx|\.tsconfig)$/;
const TS_REGEXP = /(\.ts|\.tsx)$/;
TypeScriptCompiler = class TypeScriptCompiler {
  constructor(extraOptions, maxParallelism) {
    TypeScript.validateExtraOptions(extraOptions);
    this.extraOptions = extraOptions;
    this.maxParallelism = maxParallelism || 10;
    this.serverOptions = null;
    this.tsconfig = TypeScript.getDefaultOptions();
    this.cfgHash = null;
    this.diagHash = new Set();
    this.archSet = new Set();
  }

  getFilesToProcess(inputFiles) {
    const pexclude = Logger.newProfiler('exclude');
    inputFiles = this._filterByDefault(inputFiles);

    this._processConfig(inputFiles);

    inputFiles = this._filterByConfig(inputFiles);

    if (inputFiles.length) {
      const arch = inputFiles[0].getArch();
      inputFiles = this._filterByArch(inputFiles, arch);
    }

    pexclude.end();
    return inputFiles;
  }

  getBuildOptions(inputFiles) {
    this._processConfig(inputFiles);

    const inputFile = inputFiles[0];
    let {
      compilerOptions
    } = this.tsconfig; // Make a copy.

    compilerOptions = Object.assign({}, compilerOptions);

    if (!isWeb(inputFile) && this.serverOptions) {
      Object.assign(compilerOptions, this.serverOptions);
    } // Apply extra options.


    if (this.extraOptions) {
      Object.assign(compilerOptions, this.extraOptions);
    }

    const arch = inputFile.getArch();
    const {
      typings,
      useCache
    } = this.tsconfig;
    return {
      arch,
      compilerOptions,
      typings,
      useCache
    };
  }

  processFilesForTarget(inputFiles, getDepsContent) {
    extendFiles(inputFiles, WarnMixin);
    const options = this.getBuildOptions(inputFiles);
    Logger.log('compiler options: %j', options.compilerOptions);
    inputFiles = this.getFilesToProcess(inputFiles);
    if (!inputFiles.length) return;
    const pcompile = Logger.newProfiler('compilation');
    const filePaths = inputFiles.map(file => getExtendedPath(file));
    Logger.log('compile files: %s', filePaths);
    const pbuild = Logger.newProfiler('tsBuild');

    const defaultGet = this._getContentGetter(inputFiles);

    const getContent = filePath => getDepsContent && getDepsContent(filePath) || defaultGet(filePath);

    const tsBuild = new TSBuild(filePaths, getContent, options);
    pbuild.end();
    const pfiles = Logger.newProfiler('tsEmitFiles');
    const future = new Future(); // Don't emit typings.

    const compileFiles = inputFiles.filter(file => !isDeclaration(file));
    let throwSyntax = false;
    const results = new Map();
    async.eachLimit(compileFiles, this.maxParallelism, (file, done) => {
      const co = options.compilerOptions;
      const filePath = getExtendedPath(file);
      const pemit = Logger.newProfiler('tsEmit');
      const result = tsBuild.emit(filePath);
      results.set(file, result);
      pemit.end();
      throwSyntax = throwSyntax | this._processDiagnostics(file, result.diagnostics, co);
      done();
    }, future.resolver());
    pfiles.end();
    future.wait();

    if (!throwSyntax) {
      results.forEach((result, file) => {
        const module = options.compilerOptions.module;

        this._addJavaScript(file, result, module === 'none');
      });
    }

    pcompile.end();
  }

  _getContentGetter(inputFiles) {
    const filesMap = new Map();
    inputFiles.forEach((inputFile, index) => {
      filesMap.set(getExtendedPath(inputFile), index);
    });
    return filePath => {
      let index = filesMap.get(filePath);

      if (index === undefined) {
        const filePathNoRootSlash = filePath.replace(/^\//, '');
        index = filesMap.get(filePathNoRootSlash);
      }

      return index !== undefined ? inputFiles[index].getContentsAsString() : null;
    };
  }

  _addJavaScript(inputFile, tsResult, forceBare) {
    const source = inputFile.getContentsAsString();
    const inputPath = inputFile.getPathInPackage();
    const outputPath = TypeScript.removeTsExt(inputPath) + '.js';
    const toBeAdded = {
      sourcePath: inputPath,
      path: outputPath,
      data: tsResult.code,
      hash: tsResult.hash,
      sourceMap: tsResult.sourceMap,
      bare: forceBare || isBare(inputFile)
    };
    inputFile.addJavaScript(toBeAdded);
  }

  _processDiagnostics(inputFile, diagnostics, tsOptions) {
    // Remove duplicated warnings for shared files
    // by saving hashes of already shown warnings.
    const reduce = (diagnostic, cb) => {
      let dob = {
        message: diagnostic.message,
        sourcePath: getExtendedPath(inputFile),
        line: diagnostic.line,
        column: diagnostic.column
      };
      const arch = inputFile.getArch(); // TODO: find out how to get list of architectures.

      this.archSet.add(arch);
      let shown = false;

      for (const key of this.archSet.keys()) {
        if (key !== arch) {
          dob.arch = key;
          const hash = getShallowHash(dob);

          if (this.diagHash.has(hash)) {
            shown = true;
            break;
          }
        }
      }

      if (!shown) {
        dob.arch = arch;
        const hash = getShallowHash(dob);
        this.diagHash.add(hash);
        cb(dob);
      }
    }; // Always throw syntax errors.


    const throwSyntax = !!diagnostics.syntacticErrors.length;
    diagnostics.syntacticErrors.forEach(diagnostic => {
      reduce(diagnostic, dob => {
        inputFile.error(dob);
      });
    });
    const packageName = inputFile.getPackageName();
    if (packageName) return throwSyntax; // And log out other errors except package files.

    if (tsOptions && tsOptions.diagnostics) {
      diagnostics.semanticErrors.forEach(diagnostic => {
        reduce(diagnostic, dob => inputFile.warn(dob));
      });
    }

    return throwSyntax;
  }

  _getFileModuleName(inputFile, options) {
    if (options.module === 'none') return null;
    return getES6ModuleName(inputFile);
  }

  _processConfig(inputFiles) {
    const tsFiles = inputFiles.map(inputFile => inputFile.getPathInPackage()).filter(filePath => TS_REGEXP.test(filePath));

    for (const inputFile of inputFiles) {
      // Parse root config.
      if (isMainConfig(inputFile)) {
        const source = inputFile.getContentsAsString();
        const hash = inputFile.getSourceHash(); // If hashes differ, create new tsconfig. 

        if (hash !== this.cfgHash) {
          this.tsconfig = this._parseConfig(source, tsFiles);
          this.cfgHash = hash;
        }

        return;
      } // Parse server config.
      // Take only target and lib values.


      if (isServerConfig(inputFile)) {
        const source = inputFile.getContentsAsString();

        const {
          compilerOptions
        } = this._parseConfig(source, tsFiles);

        if (compilerOptions) {
          const {
            target,
            lib
          } = compilerOptions;
          this.serverOptions = {
            target,
            lib
          };
        }

        return;
      }
    }
  }

  _parseConfig(cfgContent, tsFiles) {
    let tsconfig = null;

    try {
      tsconfig = JSON.parse(cfgContent); // Define files since if it's not defined
      // validation throws an exception.

      const files = tsconfig.files || tsFiles;
      tsconfig.files = files;
      validateTsConfig(tsconfig);
    } catch (err) {
      throw new Error(`Format of the tsconfig is invalid: ${err}`);
    }

    const exclude = tsconfig.exclude || [];

    try {
      const regExp = getExcludeRegExp(exclude);
      tsconfig.exclude = regExp && new RegExp(regExp);
    } catch (err) {
      throw new Error(`Format of an exclude path is invalid: ${err}`);
    }

    return tsconfig;
  }

  _filterByDefault(inputFiles) {
    inputFiles = inputFiles.filter(inputFile => {
      const path = inputFile.getPathInPackage();
      return COMPILER_REGEXP.test(path) && !defExclude.test('/' + path);
    });
    return inputFiles;
  }

  _filterByConfig(inputFiles) {
    let resultFiles = inputFiles;

    if (this.tsconfig.exclude) {
      resultFiles = resultFiles.filter(inputFile => {
        const path = inputFile.getPathInPackage(); // There seems to an issue with getRegularExpressionForWildcard:
        // result regexp always starts with /.

        return !this.tsconfig.exclude.test('/' + path);
      });
    }

    return resultFiles;
  }

  _filterByArch(inputFiles, arch) {
    check(arch, String); /**
                          * Include only typings that current arch needs,
                          * typings/main is for the server only and
                          * typings/browser - for the client.
                          */
    const filterRegExp = /^web/.test(arch) ? exlWebRegExp : exlMainRegExp;
    inputFiles = inputFiles.filter(inputFile => {
      const path = inputFile.getPathInPackage();
      return !filterRegExp.test('/' + path);
    });
    return inputFiles;
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/typescript.js                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
const meteorTS = Npm.require('meteor-typescript');

TypeScript = {
  validateOptions(options) {
    if (!options) return;
    meteorTS.validateAndConvertOptions(options);
  },

  // Extra options are the same compiler options
  // but passed in the compiler constructor.
  validateExtraOptions(options) {
    if (!options) return;
    meteorTS.validateAndConvertOptions({
      compilerOptions: options
    });
  },

  getDefaultOptions: meteorTS.getDefaultOptions,

  compile(source, options) {
    options = options || meteorTS.getDefaultOptions();
    return meteorTS.compile(source, options);
  },

  setCacheDir(cacheDir) {
    meteorTS.setCacheDir(cacheDir);
  },

  isDeclarationFile(filePath) {
    return (/^.*\.d\.ts$/.test(filePath)
    );
  },

  removeTsExt(path) {
    return path && path.replace(/(\.tsx|\.ts)$/g, '');
  }

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/barbatus_typescript-compiler/utils.js                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  getShallowHash: () => getShallowHash
});

const {
  createHash
} = Npm.require('crypto');

function getShallowHash(ob) {
  const hash = createHash('sha1');
  const keys = Object.keys(ob);
  keys.sort();
  keys.forEach(key => {
    hash.update(key).update('' + ob[key]);
  });
  return hash.digest('hex');
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/barbatus:typescript-compiler/logger.js");
require("./node_modules/meteor/barbatus:typescript-compiler/file-utils.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript-compiler.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript.js");
require("./node_modules/meteor/barbatus:typescript-compiler/utils.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['barbatus:typescript-compiler'] = {}, {
  TypeScript: TypeScript,
  TypeScriptCompiler: TypeScriptCompiler
});

})();

//# sourceMappingURL=barbatus_typescript-compiler.js.map
