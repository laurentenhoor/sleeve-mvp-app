(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['standard-minifier-js'] = {};

})();
