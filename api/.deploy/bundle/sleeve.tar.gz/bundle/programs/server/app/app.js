var require = meteorInstall({"server":{"collections":{"feeds.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// server/collections/feeds.js                                          //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Feeds = new meteor_rxjs_1.MongoObservable.Collection('feeds');

//////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// server/collections/index.js                                          //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("/server/collections/feeds"));

//////////////////////////////////////////////////////////////////////////

}},"models.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// server/models.js                                                     //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
Object.defineProperty(exports, "__esModule", { value: true });
var FeedType;
(function (FeedType) {
    FeedType[FeedType["MANUAL"] = 'manual'] = "MANUAL";
    FeedType[FeedType["SMART"] = 'smart'] = "SMART";
})(FeedType = exports.FeedType || (exports.FeedType = {}));

//////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// server/publications.js                                               //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
Object.defineProperty(exports, "__esModule", { value: true });
var feeds_1 = require("/server/collections/feeds");
Meteor.publish('feeds', function () {
    return feeds_1.Feeds.collection.find({}, {});
});

//////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// server/main.js                                                       //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var feeds_1 = require("/server/collections/feeds");
var models_1 = require("/server/models");
meteor_1.Meteor.startup(function () {
    // code to run on server at startup
    if (feeds_1.Feeds.find({}).cursor.count() === 0) {
        var feedId = void 0;
        feedId = feeds_1.Feeds.collection.insert({
            type: models_1.FeedType.SMART,
            amount: 70.87378640776699,
            weights: [60, -13],
            errorCode: 0,
            timestamp: Date.now()
        });
    }
});

//////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts"
  ]
});
require("./server/collections/feeds.js");
require("./server/collections/index.js");
require("./server/models.js");
require("./server/publications.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
